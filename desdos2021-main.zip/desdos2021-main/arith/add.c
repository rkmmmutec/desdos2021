
int add(int a, int b)
{
    int sum = 0;
    sum = a + b;

    sub(40, 50);
    return sum;
}