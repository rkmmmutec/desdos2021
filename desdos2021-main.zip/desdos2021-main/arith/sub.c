
int sub(int a, int b)
{
    int diff = 0;
    diff = a - b;
    return diff;
}