arm-none-eabi-objcopy -O binary firstboot.elf firstboot.bin
