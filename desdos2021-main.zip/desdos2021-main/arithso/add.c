
int add(int a, int b)
{
    int sum = 0;
    sum = a + b;
    return sum;
}