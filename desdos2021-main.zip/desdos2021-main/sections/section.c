#include <stdio.h>

int a;
int b = 10;

int main(int argc, char const *argv[])
{
    int c = 20;
    add(30, 40);

    return 0;
}
