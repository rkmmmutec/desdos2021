#include <stdio.h>
#include "arith.h"

int main(int argc, char const *argv[])
{
    int s = 0;
    s = add(50, 60);
    printf("Addition @ Noida: %d\n", s);
    return 0;
}
