int x = 10;
int y = 10;

int add(int a, int b)
{
    int sum = 0;
    sum = a + b;
    return sum;
}